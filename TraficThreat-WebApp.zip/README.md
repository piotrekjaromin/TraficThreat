# TraficThreat

Wykorzystane technologie:
-Java 8
-JBoss wildfly 10.0.0 Final
-Spring MVC 4
-Spring Security 4
-Hibernate 5.0.2 Final
